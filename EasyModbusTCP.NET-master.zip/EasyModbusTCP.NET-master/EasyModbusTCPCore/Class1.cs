﻿using System;

namespace EasyModbusTCPCore
{
    public class Class1
    {
    }
}
